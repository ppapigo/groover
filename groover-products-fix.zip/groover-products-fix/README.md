# 🚀 Groover Products Module 수정 가이드

## 📦 포함된 파일

```
groover-products-fix/
├── groover-schema-fix.sql    # PostgreSQL 스키마 업데이트 SQL
├── prisma-schema.prisma      # 업데이트된 Prisma 스키마 (전체)
├── products.service.ts       # Products 서비스 로직
├── products.controller.ts    # Products 컨트롤러
├── products-dto.ts           # DTO 파일들 (3개 합본)
├── products.module.ts        # Products 모듈 정의
├── prisma-seed.ts           # 테스트 데이터 시딩 스크립트
└── test-products-api.sh     # API 테스트 스크립트
```

---

## 🔧 Step 1: PostgreSQL 스키마 업데이트

### 방법 A: psql 사용
```powershell
# PowerShell에서 실행
cd C:\dev\groover\groover-api
psql -U groover_user -d groover -f groover-schema-fix.sql
# 비밀번호: 142857
```

### 방법 B: pgAdmin 사용
1. pgAdmin 열기
2. groover 데이터베이스 선택
3. Query Tool 열기
4. `groover-schema-fix.sql` 내용 붙여넣기
5. Execute (F5)

### 방법 C: 직접 SQL 실행
```sql
-- 누락된 컬럼 추가
ALTER TABLE products ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS subcategory VARCHAR(255);
ALTER TABLE products ADD COLUMN IF NOT EXISTS source VARCHAR(255) DEFAULT 'manual';
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- 기존 데이터 기본값 설정
UPDATE products SET source = 'manual' WHERE source IS NULL;
UPDATE products SET is_active = TRUE WHERE is_active IS NULL;

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_products_source ON products(source);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON products(is_active);
```

---

## 🔧 Step 2: Prisma 스키마 & 클라이언트 업데이트

```powershell
cd C:\dev\groover\groover-api

# Prisma 스키마 파일 교체 (prisma-schema.prisma 내용을 prisma/schema.prisma에 복사)

# Prisma 클라이언트 재생성
npx prisma generate

# DB 스키마와 동기화 확인
npx prisma db pull

# 또는 마이그레이션 생성 (권장)
npx prisma migrate dev --name add_product_fields
```

---

## 🔧 Step 3: Products Module 파일 복사

```powershell
# 파일 복사 경로
C:\dev\groover\groover-api\src\products\

# 복사할 파일:
# products.module.ts → src/products/products.module.ts
# products.service.ts → src/products/products.service.ts
# products.controller.ts → src/products/products.controller.ts

# DTO 파일은 분리해서 복사:
# products-dto.ts 내용을 아래 3개 파일로 분리:
# → src/products/dto/create-product.dto.ts
# → src/products/dto/update-product.dto.ts
# → src/products/dto/filter-product.dto.ts
```

---

## 🔧 Step 4: App Module에 등록

`src/app.module.ts` 파일에서 ProductsModule 임포트 확인:

```typescript
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ProductsModule } from './products/products.module';  // 추가
import { PrismaModule } from './prisma/prisma.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    UsersModule,
    ProductsModule,  // 추가
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
```

---

## 🔧 Step 5: 서버 실행 & 테스트

```powershell
# 1. 서버 시작
cd C:\dev\groover\groover-api
npm run start:dev

# 2. 테스트 데이터 생성 (별도 터미널)
npx ts-node prisma/seed.ts

# 3. API 테스트
# Git Bash 또는 WSL에서:
bash test-products-api.sh

# 또는 PowerShell/curl로 개별 테스트:
```

---

## 🧪 API 테스트 (PowerShell)

```powershell
# Health Check
curl http://localhost:3000/v1/health

# 로그인
$body = '{"email":"test@groover.com","password":"password123"}'
$response = Invoke-RestMethod -Uri "http://localhost:3000/v1/auth/login" -Method POST -Body $body -ContentType "application/json"
$token = $response.accessToken

# 상품 목록 조회 (인증 불필요)
curl http://localhost:3000/v1/products

# 상품 검색
curl "http://localhost:3000/v1/products/search?q=사과"

# 카테고리 목록
curl http://localhost:3000/v1/products/categories

# 상품 등록 (인증 필요)
$headers = @{ "Authorization" = "Bearer $token" }
$productBody = @{
  name = "테스트 상품"
  price = 10000
  category = "FOOD"
  source = "manual"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:3000/v1/products" -Method POST -Body $productBody -ContentType "application/json" -Headers $headers
```

---

## ✅ 체크리스트

- [ ] PostgreSQL 스키마 업데이트 완료
- [ ] `npx prisma generate` 실행
- [ ] Products Module 파일 복사
- [ ] App Module에 ProductsModule 등록
- [ ] 서버 정상 시작 확인
- [ ] 테스트 데이터 시딩
- [ ] API 테스트 통과

---

## 🐛 문제 해결

### TypeScript 컴파일 에러
```powershell
# 캐시 삭제 후 재시작
rm -rf dist/
npm run build
npm run start:dev
```

### Prisma 에러
```powershell
# Prisma 재설정
npx prisma generate
npx prisma migrate reset  # 주의: 데이터 삭제됨
```

### 포트 충돌
```powershell
# 3000 포트 사용 중인 프로세스 확인
netstat -ano | findstr :3000
# PID로 종료
taskkill /PID <PID> /F
```

---

## 📝 다음 단계

1. ✅ Products Module 완성
2. ⏳ Carts Module 개발
3. ⏳ Recommendations Module 개발
4. ⏳ Groover Code Module 개발
5. ⏳ AI 엔진 연동

---

문제가 있으면 말씀해주세요! 🙌
